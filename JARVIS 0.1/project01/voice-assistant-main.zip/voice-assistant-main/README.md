# How I Built My Own Voice Assistant

## [Watch It On YouTube](https://www.youtube.com/watch?v=UmNe36dizP4)

**Voice Assistant Using Python** <br>

I created a voice assistant with Python that can order a pizza, send an email, solve a math problem, send messages and do much more.

Subscribe To My [YouTube Channel.](https://www.youtube.com/c/DeonCardoza)

Follow Me On [Instagram.](https://www.instagram.com/)

![maxresdefault (6)](https://user-images.githubusercontent.com/62986555/208672835-40e7d1cc-5b5f-4f33-bddb-28263a35f4e3.jpg)
